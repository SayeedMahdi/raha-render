const blogs = [
    {

    }
];

export default blogs;
